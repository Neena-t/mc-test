<?php
namespace App\Http\Controllers;

use DB;
use Hash; 
use Session;
use Mail;
use File;
use App\Models\Tests;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\Auth;
use PHPExcel_IOFactory;
use PHPExcel_Style_NumberFormat;
use PHPExcel_Style_Protection;
use PHPExcel;
use PHPExcel_Writer_Excel2007;


class TestController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {

    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
	    
        return view('mcn-test.index');
	
    }

    public function testLogin(Request $request)
    {

       
        $email = $request->get('username');
        $password = $request->get('password');


         if($email == "admin@admin.com" && $password == "password"){
                 
                  $check_user = DB::table('tests')
                         ->where('email', $email)
                         ->where('password', $password)
                         ->where('role', 'admin')
                         ->first();

             
                 $user_id =  $check_user->id;
                 Session::put('user_id', $user_id);
                     
                   
                    $customers = DB::table('tests')
                                     ->where('role', 'user')
                                     ->get();
                     return view('mcn-test.admin-index',[

                         'check_user' => $check_user,
                         'customers' => $customers
                     ]);
         }
         else{


                         return view('mcn-test.index');
            }
    }

    public function createCustomer()
    {
                      $user_id = Session::get('user_id');
                      $check_user = DB::table('tests')
                         ->where('role', 'admin')
                         ->where('id', $user_id)
                         ->first();
        
           return view('mcn-test.create',[

                         'check_user' => $check_user
                     ]);
    }

    public function addCustomer(Request $request)
    {

      
                $data = array(
                    'name' =>$request->get('name'),
                    'place' => $request->get('place'),
                    'phone_number' => $request->get('number'),
                    'role' => 'user',
                    'created_at' => date("Y-m-d")
                );
                $response = Tests::insert($data);
                   if($response){

                    $customers = DB::table('tests')
                                     ->where('role', 'user')
                                     ->get();

                     $user_id = Session::get('user_id');
                      $check_user = DB::table('tests')
                         ->where('role', 'admin')
                         ->where('id', $user_id)
                         ->first();

                     return view('mcn-test.admin-index',[

                         'check_user' => $check_user,
                         'customers' => $customers
                     ]);
                   }
                   else{
                    return view('mcn-test.index');
                   }               
       
    }


    public function customerEdit($id)
    {
      
         $customer = DB::table('tests')
                                     ->where('id', $id)
                                     ->first();
         $user_id = Session::get('user_id');
         $check_user = DB::table('tests')
                         ->where('id', $user_id)
                         ->where('role', 'admin')
                         ->first();
                    return view('mcn-test.edit',[

                         'check_user' => $check_user,
                         'customer' => $customer
                     ]);
    }

    public function customerUpdate(Request $request)
    {

                  $edit =  DB::table('tests')
                              ->where('id', $request->get('customer_id'))
                              ->update(array(
                            'name' => $request->get('name'),
                            'place' => $request->get('place'),
                            'phone_number' => $request->get('number')
                        ));
 
         
                 $user_id = Session::get('user_id');
                 $check_user = DB::table('tests')
                         ->where('id', $user_id)
                         ->where('role', 'admin')
                         ->first();
                     
                   
                    $customers = DB::table('tests')
                                     ->where('role', 'user')
                                     ->get();
                     return view('mcn-test.admin-index',[

                         'check_user' => $check_user,
                         'customers' => $customers
                     ]);
            

     }
     public function customerDelete($id)
    {
    

                     $customer = DB::table('tests')
                                     ->where('id', $id)
                                     ->delete();


                 $user_id = Session::get('user_id');
                 $check_user = DB::table('tests')
                         ->where('id', $user_id)
                         ->where('role', 'admin')
                         ->first();
                     
                    
                    $customers = DB::table('tests')
                                     ->where('role', 'user')
                                     ->get();
                    
                  return redirect('mcntest/list');
    }
    public function list()
    {
                 $user_id = Session::get('user_id');
                 $check_user = DB::table('tests')
                         ->where('id', $user_id)
                         ->where('role', 'admin')
                         ->first();

                $customers = DB::table('tests')
                                     ->where('role', 'user')
                                     ->get();

                return view('mcn-test.admin-index',[

                         'check_user' => $check_user,
                         'customers' => $customers
                     ]);

    }

    public function exportCustomers()
    {

        include('./phpToPDF/phpToPDF.php');
  


        
        $table = "<table width=\'100%\' border=\'1\'>";
        $headtr = "<tr><td>Sl:No</td><td>Name</td><td>Place</td><td>Phone No</td>";
        $headtr .= "</tr>";
        $table .= $headtr;

                 $user_id = Session::get('user_id');
                 $check_user = DB::table('tests')
                         ->where('id', $user_id)
                         ->where('role', 'admin')
                         ->first();

                $customers = DB::table('tests')
                                     ->where('role', 'user')
                                     ->get();

               //export

         foreach($customers as $key=>$row) {


              
                $bodytr = "<tr>";
                $bodytr .= "<td>" . ++$key . "</td>";
                $bodytr .= "<td>" . $row->name . "</td>";
                $bodytr .= "<td>" . $row->place . "</td>";
                $bodytr .= "<td>" . $row->phone_number . "</td>";
                $bodytr .= "</tr>";
                $table .= $bodytr;
              
            }


            $table .= "</table>";
            $filename = "Customers";


            header("Content-type: application/octet-stream");
            header("Content-Disposition: attachment; filename=" . $filename . ".xls");
            header("Pragma: no-cache");
            header("Expires: 0");
            print $table;
            exit;



    }
   
}

