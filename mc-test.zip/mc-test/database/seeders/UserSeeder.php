<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('tests')->insert([
            'name' => 'Admin',
            'place' => '',
            'email' => 'admin@admin.com',
            'role' => 'admin',
            'phone_number' => '',
            'password' => 'password',
        ]);
    }
}
