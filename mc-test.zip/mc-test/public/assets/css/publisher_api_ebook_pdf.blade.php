@extends('layouts.publisher-test')
@section('title', 'Knungle | Test')
<!doctype html>
  
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>My PDF Viewer</title>
  <script
    src="https://cdnjs.cloudflare.com/ajax/libs/pdf.js/2.0.943/pdf.min.js">
  </script>
 <style type="text/css">
    body {
      background:black;
      overflow-y: hidden;
    }
    .whiteBG{
      background:black !important;
    }
    .modal-backdrop .fade .show{
      display: none !important;
    }
    .modal-backdrop{
      display: none !important;
    }
    
    .summernote img, .note-editable img {
      max-width: 100%;
      max-height: 230px;
      object-fit: cover;
    }
      #canvas_container {
          overflow: auto;
          /* width: 100%;
          height: 100%;
          background: #333;
          text-align: center;
          border: solid 3px; */
      }
     
 
   
  </style>
</head>
<body>

    <div class="hoverSpace" @if(isset($is_lesson) && $is_lesson == true) onclick="location.reload();" @endif style="cursor: pointer;"> 
        <div class="divPosBtn triggBtn" @if(isset($is_lesson) && $is_lesson == true) onclick="location.reload();" @endif style="background-color: #ffffffa1 !important;"><img class="closeImg" src="{{url('assets/img/utilities/close_2.svg')}}"></div>
    </div>   
    
     <div id="my_pdf_viewer">
        <div class="pdfTop_header wraper">
          <div id="navigation_controls">
              <input class="pageCounts-pdf" id="current_page" value="1" type="text"/>
          </div>
          <div id="zoom_controls">  
              <button class="zoomIc zoomIn" id="zoom_in">+</button>
              <button class="zoomIc zoomOut" id="zoom_out">-</button>
          </div>
        </div>

        <div class="navPdf" id="navigation_controls">
            <button class="btnArw arowLeft" id="go_previous">Previous</button>
            <!-- <input id="current_page" value="1" type="number"/> -->
            <button class="btnArw arowRight" id="go_next">Next</button>
        </div>

        <div class="canvasWraper wraper" id="canvas_container">
            <canvas id="pdf_renderer"></canvas>
        </div>
        
    </div>

    <div class="container">
  
  <!-- Trigger the modal with a button -->
  <button type="button" style="visibility: hidden;" class="btn btn-info " id="id_modal" data-toggle="modal" data-target="#myModal">Open Modal</button>

  <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog" style="margin-top: 10%;">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header" style="border-bottom: 0px solid #e5e5e5;padding-bottom: 0px;">
            <span class="num Qs_num" style="padding-top:0px;margin-bottom: -10px;font-size: 30px;color: #3a569d;width: 100%;">How would you rate this card?</span> 
          <button type="button" class="close" data-dismiss="modal">
            <img src="https://knungle.com/assets/img/utilities/close_2.svg" class="rating_close" style="width:18px;cursor: pointer;display: none;">
          </button>
         
        </div>
        <div class="modal-body">

                            

                            <div class="col-12">
           
                                <div class="row">
                                    <div class="col-12 col-md-12" style="font-size: 2em;text-align: center;">
                                          <!-- <span class="num Qs_num" style="padding-top:0px;margin-bottom: 0px;font-size: 33px;color: #3a569d;width: 100%;">How would you rate this card?</span>  -->
                                       <div id="read_not" style="width: 90%;float: left;text-align: right;height: 40px;background: #ff000000;position: absolute;display: none;"></div>  
                                       <div style="width: 100%;float: left;color: rgb(252, 215, 3);text-align: center;padding-left: 5px;" id="review"></div>
                                       <button class="sub_new" style="margin-top: 0px;margin-bottom: 40px;margin-top: 20px;cursor: pointer;" id="rate_save">Save Rating</button>
                                       <div id="saved_rate" style="display: none;"><span class="num Qs_num" style="padding-top:0px;margin-bottom: 41px;font-size: 22px;color: #3a569d;width: 100%;">Rating Saved!</span></div>
                                       <div><span class="num Qs_num" style="padding-top:0px;margin-bottom: 5px;font-size: 22px;color: #3a569d;width: 100%;">Report</span></div>
                                        <div style="color: #3a569d;font-size: 15px;cursor: pointer;"><span data-toggle="modal" data-target="#myModal0" onclick="second()">Error</span><span>  |  </span><span data-toggle="modal" data-target="#myModal0" onclick="first()">Copyright Infringement</span><span>  |  </span><span data-toggle="modal" data-target="#myModal0" onclick="third()">Abuse</span></div>
                                        <div></div>
                                        <input type="hidden" id="starsInput" class="">
                                        
                                    </div>

                                    

                                    
                                </div>

                            </div>

        </div>
        
      </div>
      
    </div>
  </div>




<!-- Modal -->
  <div class="modal fade" id="myModal0" role="dialog">
    <div class="modal-dialog" style="margin-top: 2%;">
    
      <!-- Modal content-->
      <div class="modal-content" style="width: 150%;margin-left: -25%;height: 500px;">
        <div class="modal-header" style="border-bottom: 0px solid #e5e5e5;padding-bottom: 0px;">
          <button type="button" class="close" data-dismiss="modal">
            <img src="https://knungle.com/assets/img/utilities/close_2.svg" style="width:25px;cursor: pointer">
          </button>
         
        </div>
        <div class="modal-body" >

                           

                            <div class="col-12">
           
                                <div class="row">
                                    <div class="col-12 col-md-12" style="font-size: 2em;text-align: center;">
                                          <span class="num Qs_num" id="title_span" style="padding-top:0px;margin-bottom: 15px;font-size: 30px;color: #3a569d;width: 90%;">Report Copyright Infringement</span> 
                                          <input type="hidden" id="error_type">
                                          <div>
                                          <span></span>
                                          </div>
                                          <div>
                                             <div id="summernote"></div>
                
                                <textarea hidden="hidden" name="description" id="description"></textarea>
                                          <!-- <textarea style="width:450px;height:200px;"></textarea> -->
                                          </div>
                                          
                                        <button class="sub_new" id="submit_error" style="cursor: pointer;">Report</button>
                                    </div>

                                    

                                    
                                </div>

                            </div>

        </div>
        <div class="modal-footer" style="border-top: 0px solid #e5e5e5;">
          <!-- <button type="button" class="btn btn-default" data-dismiss="modal">Close</button> -->
        </div>
      </div>
      
    </div>
  </div>


  
</div>

    <?php 
  
// Store the file name into variable 
   $file = $three_d_details->url; 
   $newstring = substr($file, -3);
  $filename = 'https://knungle.com/public/publisher/ebooks/'.$three_d_details->url;

 ?>
 
    <script>
        var myState = {
            pdf: null,
            currentPage: 1,
            zoom: 1
        }
      
        // pdfjsLib.getDocument('https://knungle.com/public/publisher/ebooks/620dee333d33e2091224653.pdf').then((pdf) => {
            pdfjsLib.getDocument('{{$filename}}').then((pdf) => {
      
            myState.pdf = pdf;
            render();
 
        });
 
        function render() {
            myState.pdf.getPage(myState.currentPage).then((page) => {
          
                var canvas = document.getElementById("pdf_renderer");
                var ctx = canvas.getContext('2d');
      
                var viewport = page.getViewport(myState.zoom);
 
                canvas.width = viewport.width;
                canvas.height = viewport.height;
          
                page.render({
                    canvasContext: ctx,
                    viewport: viewport
                });
            });
        }
 
        document.getElementById('go_previous').addEventListener('click', (e) => {
            if(myState.pdf == null || myState.currentPage == 1) 
              return;
            myState.currentPage -= 1;
            document.getElementById("current_page").value = myState.currentPage;
            render();
        });
 
        document.getElementById('go_next').addEventListener('click', (e) => {
            if(myState.pdf == null || myState.currentPage > myState.pdf._pdfInfo.numPages) 
               return;
            myState.currentPage += 1;
            document.getElementById("current_page").value = myState.currentPage;
            render();
        });
 
        document.getElementById('current_page').addEventListener('keypress', (e) => {
            if(myState.pdf == null) return;
          
            // Get key code
            var code = (e.keyCode ? e.keyCode : e.which);
          
            // If key code matches that of the Enter key
            if(code == 13) {
                var desiredPage = 
                document.getElementById('current_page').valueAsNumber;
                                  
                if(desiredPage >= 1 && desiredPage <= myState.pdf._pdfInfo.numPages) {
                    myState.currentPage = desiredPage;
                    document.getElementById("current_page").value = desiredPage;
                    render();
                }
            }
        });
 
        document.getElementById('zoom_in').addEventListener('click', (e) => {
            if(myState.pdf == null) return;
            myState.zoom += 0.5;
            render();
        });
 
        document.getElementById('zoom_out').addEventListener('click', (e) => {
            if(myState.pdf == null) return;
            myState.zoom -= 0.5;
            render();
        });
    </script>

    <script src="https://knungle.com/assets/js/rating.js"></script>

<script>
    $("#review").rating({
        "value": 3,
        "click": function (e) {
            console.log(e);
            $("#starsInput").val(e.stars);
        }
    });

</script>
<script type="text/javascript">
          function first()
          {
            
            $("#title_span").html('Report Copyright Infringement');
            $("#error_type").val('Report Copyright Infringement');
          }
          function second()
          {
           
            $("#title_span").html('Report Error');
            $("#error_type").val('Report Error');
          }
          function third()
          {
            
            $("#title_span").html('Report Abuse');
            $("#error_type").val('Report Abuse');
          }
          $("#submit_error").click(function()
          {
            //alert();
            var error_type=$("#error_type").val();
            //alert(error_type);
            var description = $('#summernote').summernote('code');
            //alert(description);

             var data = 
             {
                _token: $('#token_publisher').val(),
                id: $('#knungle_notes_id').val(),
               error_type: $("#error_type").val(),
               description: $('#summernote').summernote('code'),
             }
            console.log(data);
            $.ajax({
                url: baseurl + 'save-error-report',
                type: "POST",
                data: data,
                success: function (res) {
                    console.log(res);
                    if(res=='Reported')
                    {
                        alert('Report Saved!');
                    }
                    else
                    {
                        alert('Already Reported!!!');
                    }
                }
            });
           
          });
          $("#rate_save").click(function()
          {
            
             var starsInput=$("#starsInput").val();
             //alert(starsInput);

             var data = 
             {
                _token: $('#token_publisher').val(),
                id: $('#knungle_notes_id').val(),
               starsInput: $('#starsInput').val(),
             }
            console.log(data);
            $.ajax({
                url: baseurl + 'teacher-save-ratings',
                type: "POST",
                data: data,
                success: function (res) {
                    
                    //console.log(res);
                    //alert('Rating Saved!');
                    $("#rate_save").hide();
                    $("#saved_rate").show();
                    $(".rating_close").css("display","block");
                    $("#read_not").show();
                    //swal('Rating Saved!');
                }
            });

          });
        </script>
<script>
$(document).ready(function () {
 $(".filtSelc").hide();
 $('.filterBut').hide();
  $(".triggBtn").click(function() 
  {

                                var user_role=$("#user_role").val();
                                 if(user_role=='student')
                                 {
                                        var data2 = 
                                                 {
                                                    _token: $('#token_publisher').val(),
                                                    id: $('#knungle_notes_id').val(),
                                                   
                                                 }
                                                console.log(data2);
                                                $.ajax({
                                                    url: baseurl + 'student-api-start-status',
                                                    type: "POST",
                                                    data: data2,
                                                    success: function (res) 
                                                    {
                                                        
                                                        console.log(res);
                                                        
                                                      }
                                                    });
                                 }


var data = 
             {
                _token: $('#token_publisher').val(),
                id: $('#knungle_notes_id').val(),
               
             }
            console.log(data);
            $.ajax({
                url: baseurl + 'check-reference-api',
                type: "POST",
                data: data,
                success: function (res) {
                    if(res=='')
                    {

                    var data = 
                             {
                                _token: $('#token_publisher').val(),
                                id: $('#knungle_notes_id').val(),
                               
                             }
                            console.log(data);
                            $.ajax({
                                url: baseurl + 'check-teacher-save-ratings',
                                type: "POST",
                                data: data,
                                success: function (res) {
                                    
                                    console.log(res);
                                    var res1 = res.charAt(0);
                                    var res2 = res.charAt(1);

                                     if(res1==1)
                                    {

                                        if(res2==1)
                                        {
                                           
                                          $(".loader").show();
                                            window.location.href =baseurl+'teacher-notes';
                                          }
                                          else
                                          {
                                            $( "#id_modal" ).trigger( "click" );
                                          }
                                    }
                                    else
                                    {
                                     // window.location.href =baseurl+'teacher-notes';

                                     var id=$('#knungle_notes_id').val();
                                     var ref_title=$("#ref_title").val();
                                    // alert(ref_title);
                                   
                                      var answer = [];
                                      var data1 = 
                                      {
                                        _token: $('#token_publisher').val(),
                                             
                                              id       :$('#knungle_notes_id').val(),
                                              user_role :$('#user_role').val(),
                                    
                                      }
                                      console.log(data1);
                                              if(ref_title!='')
                                              {

                                                  $.ajax({
                                                    url: baseurl+'api_reference',
                                                    type: "POST",
                                                    data: data1,
                                                    success: function(res) 
                                                    {
                                                        console.log(res);
                                                        
                                                        $("#dynamic").html(res);
                                                        $('.triggBtn').hide();

                                                        if(window.navigator.standalone == true) 
                                                        {        
                                                          // make all link remain in web app mode.
                                                          $('a').click(function() {
                                                              window.location = $(this).attr('href');
                                                              return false;
                                                          });
                                                        }   
                                                     
                                                   
                                                    }
                                                  });

                                            }
                                            else
                                            {

                                                var user_role=$("#user_role").val();
                                               if(user_role=='teacher')
                                               {
                                                $(".loader").show();
                                                window.location.href =baseurl+'teacher-notes';
                                               }
                                               if(user_role=='publisher')
                                               {
                                                $(".loader").show();
                                                window.location.href =baseurl+'publisher-dashboard';
                                               }
                                               if(user_role=='student')
                                               {
                                                $(".loader").show();
                                                window.location.href =baseurl+'student-page';
                                               }

                                          }
                                    }
                                    


                                }
                            });
                       }
                      else
                      {
                        
                        $("#dyn_ref").html(res);
                        $("#id_modal_reference").trigger( "click" );

                        
                      }
                      
                      
                  }
              });


   
           

  });

$(".rating_close").click(function()
{

  var data = 
                             {
                                _token: $('#token_publisher').val(),
                                id: $('#knungle_notes_id').val(),
                               
                             }
                            console.log(data);
                            $.ajax({
                                url: baseurl + 'check-teacher-save-ratings',
                                type: "POST",
                                data: data,
                                success: function (res) {
                                    
                                    console.log(res);
                                    var res1 = res.charAt(0);
                                    var res2 = res.charAt(1);
                                    if(res1==1)
                                    {

                                        if(res2==1)
                                        {
                                           
                                              var user_role=$("#user_role").val();

                                             if(user_role=='teacher')
                                             {
                                              $(".loader").show();
                                              window.location.href =baseurl+'teacher-notes';
                                             }
                                             if(user_role=='publisher')
                                             {
                                              $(".loader").show();
                                              window.location.href =baseurl+'publisher-dashboard';
                                             }
                                             if(user_role=='student')
                                             {
                                              $(".loader").show();
                                              window.location.href =baseurl+'student-redirect';
                                             }
                                          }
                                          else
                                          {
                                            $( "#id_modal" ).trigger( "click" );
                                          }
                                    }
                                    else
                                    {
                                        var user_role=$("#user_role").val();

                                             if(user_role=='teacher')
                                             {
                                              $(".loader").show();
                                              window.location.href =baseurl+'teacher-notes';
                                             }
                                             if(user_role=='publisher')
                                             {
                                              $(".loader").show();
                                              window.location.href =baseurl+'publisher-dashboard';
                                             }
                                             if(user_role=='student')
                                             {
                                              $(".loader").show();
                                              window.location.href =baseurl+'student-redirect';
                                             }
                                    }
                                }
                            });
 

});

if (document.addEventListener)
{
    document.addEventListener('webkitfullscreenchange', exitHandler, false);
    document.addEventListener('mozfullscreenchange', exitHandler, false);
    document.addEventListener('fullscreenchange', exitHandler, false);
    document.addEventListener('MSFullscreenChange', exitHandler, false);
}

function exitHandler()
{
    if (document.webkitIsFullScreen === false)
    {
        var data = {
      _token: $('#token_publisher').val(),
            id       :$('#knungle_notes_id').val(),
    }
    // window.location.href =baseurl+'publisher-dashboard';

    var user_role=$("#user_role").val();
   if(user_role=='teacher')
   {
    window.location.href =baseurl+'teacher-notes';
   }
   if(user_role=='publisher')
   {
    window.location.href =baseurl+'publisher-dashboard';
   }
    
    }
    else if (document.mozFullScreen === false)
    {
        console.log('exit');
    }
    else if (document.msFullscreenElement === false)
    {
        console.log('exit');
    }
}
});

</script>
<style type="text/css">
  .filterBut
  {
    display: none;
  }
  .hoverSpace
  {
    background: transparent;
  }
</style>  
</body>
</html>