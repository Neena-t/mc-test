<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <!-- <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no"> -->
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Knungle is designed to enhance teaching and training quality by bringing teaching staff, students, employees, organisations and content developers or publishers on a single platform to collaborate. It is a platform to upload, organise and share videos, 3D models, 360° photos, games, eBooks, audios, documents, etc. along with support for 14 question types in multiple languages for enriching learning and teaching experiences. It is intended for teachers, training coordinators, employees, students, organisations, educational institutions, publishers & content developers.">
    <link rel="icon" href="../assets/img/favicon.ico" type="image/x-icon">
    <title>Test</title>

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="{{ URL::to('assets/css/bootstrap.min.css')}}">
	<!-- Font CSS -->

    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css" integrity="sha384-B4dIYHKNBt8Bc12p+WXckhzcICo0wtJAoU8YZTY5qE0Id1GSseTk6S+L3BlXeVIU" crossorigin="anonymous">
    <!-- Main CSS -->
    <link rel="stylesheet" href="{{ URL::to('assets/css/style.css')}}">
	<link rel="stylesheet" href="{{ URL::to('assets/css/developer.css')}}">
	<link rel="stylesheet" href="{{ URL::to('assets/css/style_jsm.css')}}">
	<link rel="stylesheet" href="{{ URL::to('assets/css/style_rah.css')}}">
    <link rel="stylesheet" href="{{ URL::to('assets/css/media.css')}}">
	<link rel="stylesheet" href="{{ URL::to('assets/css/multiselect/chosen.css')}}">
	<link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/themes/smoothness/jquery-ui.css">
	
	
	
 </head>
