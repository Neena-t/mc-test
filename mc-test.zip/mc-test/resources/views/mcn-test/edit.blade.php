<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
   <meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate" />
   <meta http-equiv="Pragma" content="no-cache" />
   <meta http-equiv="Expires" content="0" />
   <meta name="description" content="We’d love to hear from you!">
   
    <link rel="icon" href="assets/img/favicon.ico" type="image/x-icon">
    <title>Event</title>
   <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="{{ URL::to('assets/css/bootstrap.min.css')}}">
    <!-- new added datepicker-->
        <link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/themes/smoothness/jquery-ui.css">

    <!-- Font CSS -->

    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css" integrity="sha384-B4dIYHKNBt8Bc12p+WXckhzcICo0wtJAoU8YZTY5qE0Id1GSseTk6S+L3BlXeVIU" crossorigin="anonymous">
    <!-- Main CSS -->
    <link rel="stylesheet" href="{{ URL::to('assets/css/style.css')}}">
    <link rel="stylesheet" href="{{ URL::to('assets/css/media.css')}}">
     <style>
        label.error{
            color: red;
            font-family: 'Abadi MT Std Light'; 
        }
    </style>
 </head>
   
  <body class="loginBg outerPages">
      
      <div class="container">
          <div class="otherPages-wraper wraper">
              <div class="wraper">
                  <div class="logoknungle">
                   
                  </div>
                 <a href="{{url('/mcntest')}}" style="float: right;">
                        <button type="button" style="cursor: pointer;">Logout</button>
                    </a>
                 
              </div> 

              <div class="wraper contsSection-others">
                 <div class="contact-sec">
                     
                    <div class="row">
                       <div class="col-lg-12"> <h4 class="common-heading" style="text-transform: inherit;"> {{$check_user->name}}</h4> </div>
                     
                       <div class="col-lg-8 col-md-8 col-sm-12 col-xs-12 border_Right" style="margin-left:490px;border-left: none !important;">
                        <p class="topTexts_contact" style="margin-left: -286px;">Update Customer</p>
                         <form id="contact" action="{{url('mcntest/update')}}" method="POST">
                          
                            <input name="_token" type="hidden" id="token" value="{{ csrf_token() }}">
                            <input name="customer_id" type="hidden" value="{{ $customer->id }}">
                            
                            <div class="row">
                                <div class="col-lg-8 col-md-6 col-sm-12 col-xs-12">
                                    <div class="form-group">
                                        <label>Name</label>
                                        <input type="text" value="{{$customer->name}}" name="name" id="name" class="form-control" placeholder=" " required>
                                    </div>
                                
                                    <div class="form-group">
                                         <label> Place</label>
                                         <input type="text" class="form-control" id="dateEdit" value="{{$customer->place}}" name="place" required>
                                    </div>
                                
                                    <div class="form-group">
                                        <label>Phone No:</label>
                                        <input type="tel" value="{{$customer->phone_number}}" name="number" class="form-control" min="10" max="10" placeholder=" " required>
                                    </div>
                               </div>
                        
                               <div class="col-6">
                                 <input type="submit" value="Submit" class="btn subsBtns" style="margin-left: 210px;">
                               </div>
                            </div>
                        </form>
                      </div>
                   
                    </div>
                </div>
              </div> 
              
          </div> 
        <div class="clear"></div>
      </div> 

    <footer>
          <div class="container">
              <div class="ftrFlex text-center" id="foot">
                
              </div>
          </div>
      </footer>
      
      
      
  </body> 
</html>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <script src="{{ URL::to('assets/js/additional-methods.js')}}"></script>
  <script src="{{ URL::to('assets/js/jquery.validate.min.js')}}"></script>
  <!--datepicker -->
 <script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/jquery-ui.min.js"></script>
 