<?php

use App\Http\Controllers\TestController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


Route::get('/', [TestController::class, 'index']);
Route::get('/mcntest', [TestController::class, 'index']);
Route::get('/mcntest/list', [TestController::class, 'list']);
Route::get('/mcntest/export', [TestController::class, 'exportCustomers']);
Route::post('/mcntest/testLogin', [TestController::class, 'testLogin']);

Route::get('/mcntest/create', [TestController::class, 'createCustomer']);
Route::post('/mcntest/add_customer', [TestController::class, 'addCustomer']);
Route::get('/mcntest/edit/{id}', [TestController::class, 'customerEdit']);
Route::post('/mcntest/update', [TestController::class, 'customerUpdate']);
Route::get('/mcntest/delete/{id}', [TestController::class, 'customerDelete']);