<?php echo $__env->make('includes/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body class="blueBg loginBg">
   <!-- REGISTARTION FIRST START -->
   <div id="reg_first">
      <!-- HEADER START -->
      <header>
         <div class="container">
           
            <form class="form-horizontal" name="login" method="POST" action="<?php echo e(url('mcntest/testLogin')); ?>">
			   <input name="_token" type="hidden" value="<?php echo e(csrf_token()); ?>"/>
               <div class="row">
                  <div class="headerLogo col-xs-12 col-sm-3 col-lg-3">
                    
                  </div>
                  <div class="col-xs-12 col-sm-9 col-lg-9">
                     <div class="loginGroups">
                        <div class="log_inpSpc">
                           <div class="log_relt">
                              <input type="text" class="form-control" placeholder="Username" name="username" id="login_username">
                           </div>
                           <div class="log_relt">
                              <input type="password" class="form-control pasw" placeholder="Password" name="password" id="login_password">
                           </div>
                           <div class="clear"></div>
                        </div>
                      
                        <input class="subsBtns" type="submit" class="frgtPass float-right" value="Log in" >
                       
                     </div>
                  </div>
               </div>
            </form>
         </div>
      </header>
      <!-- HEADER-END -->
    
                 <?php if(session()->has('user-alert')): ?>
                     <div class="col-sm-12" style="margin-top:80px;">
                         <div class="alert  alert-success alert-dismissible fade show" role="alert" style="box-shadow: none;"> 
                            <?php echo e(session()->get('user-alert')); ?>

                           
                         </div> 
                     </div>
                    <?php endif; ?>

      <!-- CONTENT-SECTION START -->
      <section class="wraper mainWraper">
         <div class="container">
            <div class="row">
               <div class="col-md-7 col-sm-12 loginImgs">
                 
               </div>
              
               </div>
            </div>

      </section>
   </div>
   <?php echo $__env->make('includes/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\Users\sics1\Downloads\laravel_9\laravel_9\laravel_9\resources\views/mcn-test/index.blade.php ENDPATH**/ ?>