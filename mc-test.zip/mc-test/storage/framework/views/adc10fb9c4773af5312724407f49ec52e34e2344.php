
<!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="<?php echo e(URL::to('assets/js/bootstrap.min.js')); ?>"></script>
	<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
	<script src="<?php echo e(URL::to('assets/js/additional-methods.js')); ?>"></script>
    <script src="<?php echo e(URL::to('assets/js/jquery.validate.min.js')); ?>"> </script>

	<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/jquery-ui.min.js"></script>


</html>
<?php /**PATH C:\Users\sics1\Downloads\laravel_9\laravel_9\laravel_9\resources\views/includes/footer.blade.php ENDPATH**/ ?>