<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
   <meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate" />
   <meta http-equiv="Pragma" content="no-cache" />
   <meta http-equiv="Expires" content="0" />
   <meta name="description" content="We’d love to hear from you!">
   
    <link rel="icon" href="assets/img/favicon.ico" type="image/x-icon">
    <title>Event</title>
   <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?php echo e(URL::to('assets/css/bootstrap.min.css')); ?>">
    <!-- new added datepicker-->
        <link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/themes/smoothness/jquery-ui.css">

    <link rel="stylesheet" href="<?php echo e(URL::to('app/admin_assets//datatables.net-bs4/css/dataTables.bootstrap4.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::to('app/admin_assets//datatables.net-buttons-bs4/css/buttons.bootstrap4.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/chosen/1.4.2/chosen.css">
    <!-- Font CSS -->

    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css" integrity="sha384-B4dIYHKNBt8Bc12p+WXckhzcICo0wtJAoU8YZTY5qE0Id1GSseTk6S+L3BlXeVIU" crossorigin="anonymous">
    <!-- Main CSS -->
    <link rel="stylesheet" href="<?php echo e(URL::to('assets/css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::to('assets/css/media.css')); ?>">
     <style>
        label.error{
            color: red;
            font-family: 'Abadi MT Std Light'; 
        }
    </style>
 </head>
   
  <body class="loginBg outerPages">
      
      <div class="container">
          <div class="otherPages-wraper wraper">
              <div class="wraper">
                  <div class="logoknungle">
                   
                  </div>
                    <a href="<?php echo e(url('/mcntest')); ?>" style="float: right;margin-left: 20px;">
                        <button type="button" style="cursor: pointer;">Logout</button>
                    </a>
                    <a href="<?php echo e(url('/mcntest/create')); ?>" style="float: right;margin-left: 20px;">
                        <button type="button" style="cursor: pointer;">Create Customers</button>
                    </a>
                    <a href="<?php echo e(url('/mcntest/export')); ?>" style="float: right;">
                        <button type="button" style="cursor: pointer;">Export</button>
                    </a>
                    
                 
              </div> 

              <div class="wraper contsSection-others">
                 <div class="contact-sec">
                     
                    <div class="row">
                       <div class="col-lg-12"> <h4 class="common-heading" style="text-transform: inherit;"> <?php echo e($check_user->name); ?></h4> </div>
                       <div class="col-lg-12 col-md-4 col-sm-12 col-xs-12 mobile-gap">
                          
                          <div class="content mt-3">
                    <div class="animated fadeIn">
                <div class="row">

                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header">
                                <strong class="card-title">Customers</strong>
                            </div>
                            <div class="card-body">
                                <table id="bootstrap-data-table-export" class="table table-striped table-bordered">
                                    <thead>
                                        <tr>
                                            <th>No</th>
                                            <th>Name</th>
                                            <th>Place</th>
                                            <th>Phone No:</th>
                                            <th>Action</th>
                                       </tr>
                                    </thead>
                                    <tbody>
                                    
                                    <?php if(!empty($customers)): ?>
                                     
                                      <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
                                        <tr>
                                            <td><?php echo e(++$key); ?></td>
                                            <td><?php echo e($customer->name); ?></td>
                                            <td><?php echo e($customer->place); ?></td>
                                            <td><?php echo e($customer->phone_number); ?></td>
                                            <td>
                                               <a href="<?php echo e(url('mcntest/edit/'.$customer->id)); ?>"> <button type="button" class="btn btn-primary" title="Edit"> <i class="fa fa-edit"></i> &nbsp; &nbsp;Edit
                                               </button></a>
                                               <button type="button" class="btn btn-primary" onClick="clickDelete('<?php echo e($customer->id); ?>')" title="Delete"><i class="fa fa-th-list"></i> &nbsp; &nbsp;Delete</button>
                                                
                                            </td>
                                            
                                        </tr>
                                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>  
                                        
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>


                </div>
            </div><!-- .animated -->
        </div>


                       </div>
                      
                    </div>
                </div>
              </div> 
              
          </div> 
        <div class="clear"></div>
      </div> 

    <footer>
          <div class="container">
              <div class="ftrFlex text-center" id="foot">
                
              </div>
          </div>
      </footer>
      
      
      
  </body> 
</html>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <script src="<?php echo e(URL::to('assets/js/additional-methods.js')); ?>"></script>
  <script src="<?php echo e(URL::to('assets/js/jquery.validate.min.js')); ?>"></script>
  <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

  <script src="<?php echo e(URL::to('app/admin_assets/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
  <script src="<?php echo e(URL::to('app/admin_assets/datatables.net-bs4/js/dataTables.bootstrap4.min.js')); ?>"></script>
   <script src="<?php echo e(URL::to('app/admin_assets/datatables.net-buttons/js/dataTables.buttons.min.js')); ?>"></script>
   <script src="<?php echo e(URL::to('app/admin_assets/datatables.net-buttons-bs4/js/buttons.bootstrap4.min.js')); ?>"></script>

   <script src="<?php echo e(URL::to('app/admin_assets/datatables.net-buttons/js/buttons.html5.min.js')); ?>"></script>
   <script src="<?php echo e(URL::to('app/admin_assets/datatables.net-buttons/js/buttons.print.min.js')); ?>"></script>
   <script src="<?php echo e(URL::to('app/admin_assets/datatables.net-buttons/js/buttons.colVis.min.js')); ?>"></script>
   <script src="<?php echo e(URL::to('app/admin_assets//js/init-scripts/data-table/datatables-init.js')); ?>"></script>
   <script>
    // window.baseurl = 'https://knungle.com/mcntest';

    function clickDelete(id) {
       
    
         swal({
            title: "You want to delete this customer?",
            buttons: true,
            buttons: ["No", "Yes"],
            dangerMode: true,
        })
        .then((willDelete) => {
          if (willDelete) {
                   window.location.href = "<?php echo e(url('mcntest/delete')); ?>" + '/' + id;

          } else {
           alert('no');
          }
        });

         
      }

</script>   <?php /**PATH C:\Users\sics1\Downloads\laravel_9\laravel_9\laravel_9\resources\views/mcn-test/admin-index.blade.php ENDPATH**/ ?>